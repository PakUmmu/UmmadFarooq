﻿// Assignment 5 by Ummad Farooq (100704186)

using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace DcRegistrationApp
{
    public partial class Form1 : Form
    {
        private List<Student> studentArrayList = new List<Student>();
        private List<Campus> campuses = new List<Campus>();

        public Form1()
        {
            InitializeComponent();
            InitializeCampuses();
            InitializeForm();
        }

        private void InitializeForm()
        {
            cmbCampusLoc.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbPrograms.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbCampusLoc.Enabled = false;
            cmbPrograms.Enabled = false;
            cmbGrade.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbAdmission.DropDownStyle = ComboBoxStyle.DropDownList;
            CenterToScreen();
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
        }

        private void InitializeCampuses()
        {
            var programsON = new List<AdmissionProgram>
            {
                new AdmissionProgram("Engineering", 10000, 3),
                new AdmissionProgram("Business", 8000, 2)
            };
            var programsQC = new List<AdmissionProgram>
            {
                new AdmissionProgram("Law", 12000, 3),
                new AdmissionProgram("Health", 11000, 3)
            };

            campuses.Add(new Campus(70, 60, 500, programsON));
            campuses.Add(new Campus(80, 70, 600, programsQC));
        }

        private bool ValidateInputs()
        {
            bool isValid = true;

            if (string.IsNullOrWhiteSpace(txtFirstName.Text))
            {
                ShowError(txtFirstName, "First name is required.");
                isValid = false;
            }
            if (string.IsNullOrWhiteSpace(txtLastName.Text))
            {
                ShowError(txtLastName, "Last name is required.");
                isValid = false;
            }
            if (!int.TryParse(txtSIN.Text, out _))
            {
                ShowError(txtSIN, "SIN must be a valid number.");
                isValid = false;
            }
            if (!int.TryParse(cmbGrade.Text, out _))
            {
                ShowError(cmbGrade, "Select a valid high school grade.");
                isValid = false;
            }
            if (!int.TryParse(cmbAdmission.Text, out _))
            {
                ShowError(cmbAdmission, "Select a valid admission test score.");
                isValid = false;
            }

            return isValid;
        }

        private void ShowError(Control control, string message)
        {
            errorProvider1.SetError(control, message);
            control.BackColor = Color.Red;
        }

        private void ClearError(Control control)
        {
            errorProvider1.SetError(control, null);
            control.BackColor = Color.White;
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs()) return;

            int hsGrade = int.Parse(cmbGrade.Text);
            int testScore = int.Parse(cmbAdmission.Text);

            var eligibleCampuses = campuses.Where(c => c.HSGradeReq <= hsGrade && c.AdmissionTSReq <= testScore).ToList();

            if (eligibleCampuses.Count == 0)
            {
                MessageBox.Show("Student is not eligible for admission.");
                ResetFields();
            }
            else
            {
                cmbCampusLoc.Enabled = true;
                cmbCampusLoc.Items.Clear();
                eligibleCampuses.ForEach(c => cmbCampusLoc.Items.Add($"Campus {c.HSGradeReq}-{c.AdmissionTSReq}"));
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs()) return;

            var student = new Student(
                txtFirstName.Text,
                txtLastName.Text,
                int.Parse(txtSIN.Text),
                txtEmail.Text,
                int.Parse(cmbGrade.Text),
                int.Parse(cmbAdmission.Text),
                cmbCampusLoc.Text,
                cmbPrograms.Text
            );

            studentArrayList.Add(student);
            AddStudentToDataGrid(student);
            MessageBox.Show("Student registered successfully.");
            ResetFields();
        }

        private void AddStudentToDataGrid(Student student)
        {
            dgvStudents.Rows.Add(student.SIN, student.FirstName, student.LastName, student.Email, student.CampusLocation, student.ProgramName);
        }

        private void ResetFields()
        {
            txtFirstName.Clear();
            txtLastName.Clear();
            txtSIN.Clear();
            txtEmail.Clear();
            cmbGrade.SelectedIndex = -1;
            cmbAdmission.SelectedIndex = -1;
            cmbCampusLoc.Items.Clear();
            cmbCampusLoc.Enabled = false;
            cmbPrograms.Items.Clear();
            cmbPrograms.Enabled = false;
        }

        private void btnSaveToJson_Click(object sender, EventArgs e)
        {
            try
            {
                var json = JsonConvert.SerializeObject(studentArrayList, Formatting.Indented);
                File.WriteAllText("students.json", json);
                studentArrayList.Clear();
                dgvStudents.Rows.Clear();
                ResetFields();
                MessageBox.Show("Records successfully saved to JSON file and cleared.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving to JSON: {ex.Message}");
            }
        }

        private void cmbAdmission_SelectedIndexChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Admission Test Score updated.");
        }

        private void label10_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Label clicked.");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Form loaded successfully.");
        }

        private void registerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Register functionality is not implemented yet.");
        }

        private void recordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Record functionality is not implemented yet.");
        }

        private void deleteAllRecordsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            studentArrayList.Clear();
            dgvStudents.Rows.Clear();
            ResetFields();
            MessageBox.Show("All records have been removed.");
        }

        private void loadRecordsToServerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            btnSaveToJson_Click(sender, e);
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void readHelpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This is the help section. Contact technical support for further assistance.");
        }

        private void technicalSupportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Technical Support\nName: Your Name\nID: Your ID\nEmail: your.email@dc.ca");
        }

        private void aboutDCRegistrationAppToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("DC Registration App\nVersion 1.0\nManage student admissions efficiently.");
        }
    }
}
