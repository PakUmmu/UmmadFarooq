﻿// Assignment 5 by Ummad Farooq (100704186)

using System;

namespace DcRegistrationApp
{
    public class AdmissionProgram
    {
        public string ProgramName { get; set; }
        public int ProgramFees { get; set; }
        public int ProgramDuration { get; set; }

        public AdmissionProgram(string programName, int programFees, int programDuration)
        {
            ProgramName = programName;
            ProgramFees = programFees;
            ProgramDuration = programDuration;
        }
    }
}
