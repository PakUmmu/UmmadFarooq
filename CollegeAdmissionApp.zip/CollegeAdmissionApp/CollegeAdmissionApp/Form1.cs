﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace CollegeAdmissionApp
{
    public partial class Form1 : Form
    {
        private List<Student> studentArrayList = new List<Student>();
        private List<Campus> campuses = new List<Campus>();

        public Form1()
        {
            InitializeComponent();
            InitializeCampuses();
        }

        private void InitializeCampuses()
        {
            // Example campus and program data
            var programsON = new List<AdmissionProgram>
            {
                new AdmissionProgram("Engineering", 10000, 3),
                new AdmissionProgram("Business", 8000, 2)
            };

            campuses.Add(new Campus(70, 60, 500, programsON));
        }

        private bool ValidateInputs()
        {
            bool isValid = true;
            if (string.IsNullOrWhiteSpace(txtFirstName.Text)) { ShowError(txtFirstName, "First name is required."); isValid = false; }
            if (string.IsNullOrWhiteSpace(txtLastName.Text)) { ShowError(txtLastName, "Last name is required."); isValid = false; }
            if (!int.TryParse(txtSIN.Text, out _)) { ShowError(txtSIN, "SIN must be a valid number."); isValid = false; }
            if (!int.TryParse(cmbGrade.Text, out _)) { ShowError(cmbGrade, "Select a valid high school grade."); isValid = false; }
            if (!int.TryParse(cmbAdmission.Text, out _)) { ShowError(cmbAdmission, "Select a valid admission test score."); isValid = false; }
            return isValid;
        }

        private void ShowError(Control control, string message)
        {
            errorProvider1.SetError(control, message);
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs()) return;

            int hsGrade = int.Parse(cmbGrade.Text);
            int testScore = int.Parse(cmbAdmission.Text);
            var eligibleCampuses = campuses.Where(c => c.HSGradeReq <= hsGrade && c.AdmissionTSReq <= testScore).ToList();

            if (eligibleCampuses.Count == 0)
            {
                MessageBox.Show("Student is not eligible for admission.");
                ResetFields();
            }
            else
            {
                cmbCampusLoc.Items.Clear();
                eligibleCampuses.ForEach(c => cmbCampusLoc.Items.Add($"Campus with min grade {c.HSGradeReq}"));
                cmbCampusLoc.Enabled = true;
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs() || cmbCampusLoc.SelectedIndex == -1 || cmbPrograms.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a campus and program before registering.");
                return;
            }

            var selectedProgram = (AdmissionProgram)cmbPrograms.SelectedItem;
            var student = new Student(
                txtFirstName.Text,
                txtLastName.Text,
                int.Parse(txtSIN.Text),
                txtEmail.Text,
                int.Parse(cmbGrade.Text),
                int.Parse(cmbAdmission.Text),
                cmbCampusLoc.Text,
                selectedProgram.ProgramName
            );

            studentArrayList.Add(student);
            AddStudentToDataGrid(student);
            MessageBox.Show("Student registered successfully.");
        }

        private void AddStudentToDataGrid(Student student)
        {
            dgvStudents.Rows.Add(student.SIN, student.FirstName, student.LastName, student.Email, student.CampusLocation, student.ProgramName);
        }

        private void btnSaveToJson_Click(object sender, EventArgs e)
        {
            try
            {
                var json = JsonConvert.SerializeObject(studentArrayList, Formatting.Indented);
                File.WriteAllText("students.json", json);
                MessageBox.Show("Records saved to JSON.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving to JSON: {ex.Message}");
            }
        }

        private void ResetFields()
        {
            txtFirstName.Clear();
            txtLastName.Clear();
            txtSIN.Clear();
            txtEmail.Clear();
            cmbGrade.SelectedIndex = -1;
            cmbAdmission.SelectedIndex = -1;
            cmbCampusLoc.SelectedIndex = -1;
            cmbCampusLoc.Items.Clear();
            cmbCampusLoc.Enabled = false;
            cmbPrograms.SelectedIndex = -1;
            cmbPrograms.Items.Clear();
            cmbPrograms.Enabled = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
