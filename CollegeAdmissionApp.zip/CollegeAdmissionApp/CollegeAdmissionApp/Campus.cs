﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollegeAdmissionApp
{
    public class Campus
    {
        public int HSGradeReq { get; set; }
        public int AdmissionTSReq { get; set; }
        public int RegistrationFees { get; set; }
        public List<AdmissionProgram> AvailablePrograms { get; set; }

        public Campus(int hsGradeReq, int admissionTSReq, int registrationFees, List<AdmissionProgram> availablePrograms)
        {
            HSGradeReq = hsGradeReq;
            AdmissionTSReq = admissionTSReq;
            RegistrationFees = registrationFees;
            AvailablePrograms = availablePrograms;
        }
    }
}
